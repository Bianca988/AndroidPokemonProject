package com.example.androidpokemonproject;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import static android.R.layout.simple_spinner_item;

public class MainActivity extends AppCompatActivity {
   private ArrayList<Pokemon> pokemonArrayList;
    private ArrayList<String> pokemonName = new ArrayList<>();

    private Retrofit retrofit;
    private static final String TAG = "Merge";
    private Spinner spinnerlist;
    String Pokemon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        retrofit = new Retrofit.Builder()
                   .baseUrl("https://pokeapi.co/api/v2/")
                   .addConverterFactory(GsonConverterFactory.create())
                   .build();

        spinnerlist = findViewById(R.id.spinner);
        FetchData();

    }
        private void FetchData()
        {
            ApiService service = retrofit.create(ApiService.class);
            Call<RespondPokemon> respondPokemonCall = service.getPokemonList();

            respondPokemonCall.enqueue(new Callback<RespondPokemon>() {
                @Override
                public void onResponse(Call<RespondPokemon> call, Response<RespondPokemon> response)
                {

                    if(response.isSuccessful())
                    {
                        RespondPokemon respondPokemon = response.body();
                        pokemonArrayList = respondPokemon.getResults();
                        Log.d(TAG,"am ajuns aici");




                        for(int i = 0; i < pokemonArrayList.size(); i++)
                        {
                            Pokemon P = pokemonArrayList.get(i);

                            Log.i(TAG,"pokemon: "+ P.getName());
                            
                            spinner();


                        }

                    }
                    else
                    {
                        Log.e(TAG,"onResponse: ");
                    }
                }

                @Override
                public void onFailure(Call<RespondPokemon> call, Throwable t) {

                            Log.e(TAG,"FAILURE");
                }
            });
        }

        private void spinner()
        {
            String[] items = new String[pokemonArrayList.size()];

            for(int i=0; i< pokemonArrayList.size();i++)
            {
                items[i] = pokemonArrayList.get(i).getName();
            }

            ArrayAdapter<String> adapter;
            adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,items);
            spinnerlist.setAdapter(adapter);
           /* try{

                JSONObject obj = new JSONObject(p);
                if(obj.optString("count").equals("811"))
                {
                    pokemonArrayList = new ArrayList<>();
                    JSONArray dataArray = obj.getJSONArray("results");

                    for(int i = 0; i< dataArray.length(); i++)
                    {
                        Pokemon pokemon = new Pokemon();
                        JSONObject dataobj = dataArray.getJSONObject(i);

                        pokemon.setName(dataobj.getString("name"));

                        pokemonArrayList.add(pokemon);
                    }

                    for (int i =0; i< pokemonArrayList.size(); i++)
                    {
                        pokemonName.add(pokemonArrayList.get(i).getName().toString());
                    }

                    ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(MainActivity.this,simple_spinner_item,pokemonName);
                    spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                    spinnerlist.setAdapter(spinnerArrayAdapter);
                }



            }catch (JSONException e)
            {
                e.printStackTrace();
            }
      */  }



}
